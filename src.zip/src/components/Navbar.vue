<template>
  <b-navbar toggleable="lg" type="dark" variant="danger">
    <b-navbar-brand href="/">
      <img width="32" height="32" src="https://pluspng.com/img-png/marlboro-logo-png--915.png" class="d-inline-block align-top" alt="Kitten">
      Malboro
    </b-navbar-brand>

    <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>

    <b-collapse id="nav-collapse" is-nav>
      <b-navbar-nav>
        <b-nav-item href="/test1">Acerca de nosotros</b-nav-item>
        <b-nav-item href="/test2">Tabacos</b-nav-item>
      </b-navbar-nav>
    </b-collapse>
  </b-navbar>
</template>

<script>
export default {};
</script>

<style></style>
