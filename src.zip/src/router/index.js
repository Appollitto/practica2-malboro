import { createRouter, createWebHistory } from "vue-router";

import Index from "../views/Index.vue";
import Test1 from "../views/Test1.vue";
import Test2 from "../views/Test2.vue";

const routes = [
  {
    path: "/",
    name: "index",
    component: Index,
  },
  {
    path: "/test1",
    name: "test1",
    component: Test1,
  },
  {
    path: "/test2",
    name: "test2",
    component: Test2,
  }
];

const router = createRouter({
  mode: "history",
  history: createWebHistory(process.env.BASE_URL),
  routes,
  linkActiveClass: "active",
  linkExactActiveClass: "active",
});

export default router;
