<template>
  <Navbar />
  <h1>Malboro</h1>
  <img style="width:100%;" src="https://palabrasclaras.mx/wp-content/uploads/2018/12/Marlboro.jpg" alt="">
  <div>
  <b-jumbotron header="BootstrapVue" lead="Bootstrap v4 Components for Vue.js 2">
    <p>Para mas informacion visita la pagina oficial! </p>
    <b-button variant="primary" href="/test1">click aqui!</b-button>
  </b-jumbotron>
</div>
</template>

<script>
import HelloWorld from "@/components/HelloWorld.vue";
import Navbar from "@/components/Navbar.vue";

export default {
  components: { HelloWorld, Navbar },
};
</script>

<style></style>
