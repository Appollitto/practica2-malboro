<template>
  <Navbar />
  <b-container>
  <h1>Historia</h1>
  <hr>
  <img style="width:100%;" src="https://i.pinimg.com/originals/f2/3e/f8/f23ef84c3899c62cc026f48ab79a7f61.jpg" alt="">
  <hr>
  <p>
  Marlboro sin duda hizo leyenda en términos de marketing. Esta marca, fundada en 1924 por Philips Morris, dio origen a su naming  por  la calle Great Marlborough, en Nueva Jersey, donde se localizaba originalmente la fábrica. En sus inicios la marca era dirigida a mujeres, sí señor, para esa época fumar cigarrillos con boquillas o filtros era bastante afeminado para hombres, y muy bien recibido por el mercado de las damas.
 
No fue sino hasta 1950, cuando se publicó un importante estudio que relacionaba el consumo de tabaco con el cáncer, que los creativos de Marlboro tuvieron una idea multimillonaria. Estos percibieron un nuevo nicho de consumidores hombres; que querían cuidar su salud, pero deseaban fumar. Para esa época se creía que el cigarrillo sin filtro podría ser menos perjudicial que el tradicional.
 
Marlboro no dejó pasar la oportunidad y decidió reposicionar la marca. El paquete rojo y blanco fue diseñado por el diseñador Gianninoto Frank.  La campaña publicitaria  fue desarrollada por Leo Burnett, esta consistía en mostrar muchas figuras masculinas como: marines, soldados, constructores y muchos otros, entre ellos, el vaquero americano.  En un año la compañía pasó de poseer menos del uno por ciento del mercado, a ser la cuarta marca más vendida en los Estados Unidos. El vaquero se convirtió de ahí en adelante en el estandarte para conquistar el mundo.
 </p>
  </b-container>
</template>

<script>
import HelloWorld from "@/components/HelloWorld.vue";
import Navbar from "@/components/Navbar.vue";

export default {
  components: {Navbar },
};
</script>

<style></style>
