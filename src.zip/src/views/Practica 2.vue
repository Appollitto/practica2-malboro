<template>
  <Navbar />
  <h1>Tabacos disponibles</h1>
  <b-row>
    <b-col v-for="(item, index) in json" :key="index">
      <b-card no-body class="overflow-hidden">
        <b-row no-gutters>
          <b-col md="6">
            <b-card-img
              :src="item.url"
              alt="Image"
              class="rounded-0"
              fluid
            ></b-card-img>
          </b-col>
          <b-col md="6">
            <b-card-body :title="item.name">
              <b-card-text>
                {{item.description }}
              </b-card-text>
              <b-card-text>
               {{ item.price }}$
              </b-card-text>
            </b-card-body>
          </b-col>
        </b-row>
      </b-card>
    </b-col>
  </b-row>
</template>

<script>
import HelloWorld from "@/components/HelloWorld.vue";
import Navbar from "@/components/Navbar.vue";

const json = require("../assets/test.json");

export default {
  components: { HelloWorld, Navbar },

  data() {
    return {
      json: json,
    };
  },
};
</script>

<style></style>
